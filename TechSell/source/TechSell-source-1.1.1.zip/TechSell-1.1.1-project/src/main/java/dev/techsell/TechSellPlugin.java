package dev.techsell;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Server;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class TechSellPlugin extends JavaPlugin implements Listener {
    private static final int GUI_SIZE = 54;
    private static final int SELL_SLOTS = 45;
    private static final int TOTAL_SLOT = 47;
    private static final int CONFIRM_SLOT = 49;
    private static final int CANCEL_SLOT = 51;

    private final Map<Material, Double> sellPrices = new LinkedHashMap<>();
    private final Map<UUID, SellHolder> openMenus = new HashMap<>();
    private DecimalFormat moneyFormat = new DecimalFormat("#,##0.00");
    private Object economyProvider;
    private String stackValueLore = "&aWorth: &f$%value% &8(&7$%unit% each&8)";

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        getServer().getPluginManager().registerEvents(this, this);
        setupEconomy();
        getLogger().info("Loaded " + sellPrices.size() + " sellable materials.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("techsell")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(color(message("player-only", "&cThis command must be run by a player.")));
                return true;
            }
            if (!player.hasPermission("techsell.use")) {
                player.sendMessage(color(message("no-permission", "&cYou do not have permission.")));
                return true;
            }
            openSellMenu(player);
            return true;
        }

        if (command.getName().equalsIgnoreCase("techsellreload")) {
            if (!sender.hasPermission("techsell.admin")) {
                sender.sendMessage(color(message("no-permission", "&cYou do not have permission.")));
                return true;
            }
            reloadConfig();
            loadSettings();
            setupEconomy();
            sender.sendMessage(color(message("reloaded", "&aTechSell configuration reloaded.")));
            return true;
        }
        return false;
    }

    private void loadSettings() {
        sellPrices.clear();
        String format = getConfig().getString("settings.currency-format", "#,##0.00");
        try {
            moneyFormat = new DecimalFormat(format);
        } catch (IllegalArgumentException ignored) {
            moneyFormat = new DecimalFormat("#,##0.00");
        }

        stackValueLore = getConfig().getString("gui.stack-value-lore", "&aWorth: &f$%value% &8(&7$%unit% each&8)");

        ConfigurationSection section = getConfig().getConfigurationSection("sell-prices");
        if (section == null) {
            getLogger().warning("No sell-prices section found in config.yml.");
            return;
        }

        for (String key : section.getKeys(false)) {
            Material material = Material.matchMaterial(key.toUpperCase(Locale.ROOT));
            double price = section.getDouble(key, -1.0);
            if (material == null) {
                getLogger().warning("Ignoring unknown material in sell-prices: " + key);
            } else if (price <= 0.0) {
                getLogger().warning("Ignoring non-positive sell price for " + key + ": " + price);
            } else {
                sellPrices.put(material, price);
            }
        }
    }

    private void setupEconomy() {
        economyProvider = null;
        try {
            Class<?> economyClass = Class.forName("net.milkbowl.vault.economy.Economy");
            Object services = getServer().getServicesManager();
            Method registrationMethod = services.getClass().getMethod("getRegistration", Class.class);
            Object registration = registrationMethod.invoke(services, economyClass);
            if (registration != null) {
                Method providerMethod = registration.getClass().getMethod("getProvider");
                economyProvider = providerMethod.invoke(registration);
            }
        } catch (Throwable error) {
            getLogger().warning("Could not hook into Vault economy: " + error.getClass().getSimpleName() + ": " + error.getMessage());
        }
        if (economyProvider == null) {
            getLogger().warning("No Vault economy provider is available. Selling will remain disabled until one is available.");
        }
    }

    private void openSellMenu(Player player) {
        SellHolder old = openMenus.get(player.getUniqueId());
        if (old != null) {
            returnItems(player, old.inventory);
        }

        SellHolder holder = new SellHolder(player);
        Inventory inventory = getServer().createInventory(holder, GUI_SIZE,
                color(getConfig().getString("gui.title", "&8Tech Sell")));
        holder.inventory = inventory;
        openMenus.put(player.getUniqueId(), holder);
        drawControls(holder);
        player.openInventory(inventory);
    }

    private void drawControls(SellHolder holder) {
        Inventory inventory = holder.inventory;
        ItemStack filler = named(Material.GRAY_STAINED_GLASS_PANE, " ", Collections.emptyList());
        for (int slot = SELL_SLOTS; slot < GUI_SIZE; slot++) {
            inventory.setItem(slot, filler);
        }
        inventory.setItem(TOTAL_SLOT, totalItem(0.0, 0));
        inventory.setItem(CONFIRM_SLOT, named(Material.EMERALD,
                getConfig().getString("gui.confirm-name", "&a&lSell Items"),
                colorList(getConfig().getStringList("gui.confirm-lore"))));
        inventory.setItem(CANCEL_SLOT, named(Material.BARRIER,
                getConfig().getString("gui.cancel-name", "&cCancel"),
                colorList(getConfig().getStringList("gui.cancel-lore"))));
    }

    private ItemStack totalItem(double total, int count) {
        List<String> lore = new ArrayList<>();
        List<String> configured = getConfig().getStringList("gui.total-lore");
        for (String line : configured) {
            lore.add(color(line.replace("%total%", formatMoney(total)).replace("%items%", Integer.toString(count))));
        }
        return named(Material.GOLD_INGOT,
                getConfig().getString("gui.total-name", "&6&lTotal Value"), lore);
    }

    private ItemStack named(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(name));
            if (lore != null && !lore.isEmpty()) {
                meta.setLore(lore);
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof SellHolder holder)) {
            return;
        }
        HumanEntity who = event.getWhoClicked();
        if (!(who instanceof Player player) || !holder.playerId.equals(player.getUniqueId())) {
            event.setCancelled(true);
            return;
        }

        int rawSlot = event.getRawSlot();
        if (rawSlot >= SELL_SLOTS && rawSlot < GUI_SIZE) {
            event.setCancelled(true);
            if (rawSlot == CONFIRM_SLOT) {
                sellContents(player, holder);
            } else if (rawSlot == CANCEL_SLOT) {
                player.closeInventory();
            }
            return;
        }

        if (rawSlot >= 0 && rawSlot < SELL_SLOTS) {
            ItemStack current = event.getCurrentItem();
            if (!isEmpty(current)) {
                stripValueLore(current);
                event.setCurrentItem(current);
            }
            ItemStack cursor = event.getCursor();
            if (!isEmpty(cursor) && !isSellable(cursor)) {
                event.setCancelled(true);
                player.sendMessage(color(message("not-sellable", "&cThat item cannot be sold here.")));
                return;
            }
            scheduleUpdate(holder);
            return;
        }

        if (event.isShiftClick()) {
            ItemStack clicked = event.getCurrentItem();
            event.setCancelled(true);
            if (isEmpty(clicked)) {
                return;
            }
            if (!isSellable(clicked)) {
                player.sendMessage(color(message("not-sellable", "&cThat item cannot be sold here.")));
                return;
            }
            ItemStack remainder = moveIntoSellSlots(top, clicked.clone());
            int moved = clicked.getAmount() - (isEmpty(remainder) ? 0 : remainder.getAmount());
            if (moved > 0) {
                clicked.setAmount(clicked.getAmount() - moved);
                event.setCurrentItem(clicked.getAmount() <= 0 ? null : clicked);
            }
            updateTotal(holder);
            forceClientRefresh(player);
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof SellHolder holder)) {
            return;
        }
        boolean touchesSellArea = false;
        for (Integer rawSlot : event.getRawSlots()) {
            if (rawSlot >= SELL_SLOTS && rawSlot < GUI_SIZE) {
                event.setCancelled(true);
                return;
            }
            if (rawSlot >= 0 && rawSlot < SELL_SLOTS) {
                touchesSellArea = true;
            }
        }
        if (touchesSellArea && !isSellable(event.getOldCursor())) {
            event.setCancelled(true);
            HumanEntity who = event.getWhoClicked();
            if (who instanceof Player player) {
                player.sendMessage(color(message("not-sellable", "&cThat item cannot be sold here.")));
            }
            return;
        }
        scheduleUpdate(holder);
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        Inventory inventory = event.getInventory();
        if (!(inventory.getHolder() instanceof SellHolder holder)) {
            return;
        }
        HumanEntity human = event.getPlayer();
        if (human instanceof Player player) {
            returnItems(player, inventory);
        }
        openMenus.remove(holder.playerId);
    }

    private void scheduleUpdate(SellHolder holder) {
        if (holder.updateQueued) {
            return;
        }
        holder.updateQueued = true;
        getServer().getScheduler().runTask(this, () -> {
            holder.updateQueued = false;
            updateTotal(holder);
            if (holder.player != null) {
                forceClientRefresh(holder.player);
            }
        });
    }


    private void forceClientRefresh(Player player) {
        try {
            Method method = player.getClass().getMethod("updateInventory");
            method.invoke(player);
        } catch (Throwable ignored) {
            // Inventory packets are still sent normally if this compatibility hint is unavailable.
        }
    }

    private void updateTotal(SellHolder holder) {
        if (holder.inventory == null) {
            return;
        }
        double total = 0.0;
        int count = 0;
        for (int slot = 0; slot < SELL_SLOTS; slot++) {
            ItemStack item = holder.inventory.getItem(slot);
            if (!isEmpty(item) && isSellable(item)) {
                double unitPrice = sellPrices.get(item.getType());
                total += unitPrice * item.getAmount();
                count += item.getAmount();
                applyValueLore(item, unitPrice);
            }
        }
        holder.inventory.setItem(TOTAL_SLOT, totalItem(total, count));
    }

    private void sellContents(Player player, SellHolder holder) {
        if (economyProvider == null) {
            setupEconomy();
        }
        if (economyProvider == null) {
            player.sendMessage(color(message("no-economy", "&cNo Vault economy provider is available.")));
            return;
        }

        double total = 0.0;
        int count = 0;
        for (int slot = 0; slot < SELL_SLOTS; slot++) {
            ItemStack item = holder.inventory.getItem(slot);
            if (!isEmpty(item) && isSellable(item)) {
                stripValueLore(item);
                total += sellPrices.get(item.getType()) * item.getAmount();
                count += item.getAmount();
            }
        }
        if (count == 0 || total <= 0.0) {
            player.sendMessage(color(message("nothing-to-sell", "&cThere are no sellable items in the menu.")));
            return;
        }

        if (!deposit(player, total)) {
            player.sendMessage(color(message("payment-failed", "&cThe economy payment failed. Your items were not removed.")));
            return;
        }

        for (int slot = 0; slot < SELL_SLOTS; slot++) {
            holder.inventory.setItem(slot, null);
        }
        updateTotal(holder);
        player.sendMessage(color(message("sold", "&aSold &e%items% items &afor &6$%total%&a.")
                .replace("%items%", Integer.toString(count))
                .replace("%total%", formatMoney(total))));
    }

    private boolean deposit(Player player, double amount) {
        String vaultFailure = "No compatible depositPlayer method was found.";
        try {
            for (Method method : economyProvider.getClass().getMethods()) {
                if (!method.getName().equals("depositPlayer") || method.getParameterCount() != 2) {
                    continue;
                }
                Class<?> first = method.getParameterTypes()[0];
                Object target;
                if (first.isInstance(player)) {
                    target = player;
                } else if (first == String.class) {
                    target = player.getName();
                } else {
                    continue;
                }
                Object response = method.invoke(economyProvider, target, amount);
                if (response == null) {
                    getLogger().info("Paid " + player.getName() + " " + formatMoney(amount) + " using Vault.");
                    return true;
                }
                try {
                    Method success = response.getClass().getMethod("transactionSuccess");
                    Object result = success.invoke(response);
                    if (!(result instanceof Boolean) || (Boolean) result) {
                        getLogger().info("Paid " + player.getName() + " " + formatMoney(amount) + " using Vault.");
                        return true;
                    }
                    vaultFailure = readResponseError(response);
                } catch (NoSuchMethodException ignored) {
                    getLogger().info("Paid " + player.getName() + " " + formatMoney(amount) + " using Vault.");
                    return true;
                }
            }
        } catch (Throwable error) {
            vaultFailure = error.getClass().getSimpleName() + ": " + error.getMessage();
        }

        getLogger().warning("Vault deposit did not succeed for " + player.getName() + ": " + vaultFailure);
        return depositUsingCommand(player, amount);
    }

    private String readResponseError(Object response) {
        try {
            Method errorMessage = response.getClass().getMethod("errorMessage");
            Object value = errorMessage.invoke(response);
            if (value != null && !value.toString().isBlank()) return value.toString();
        } catch (Throwable ignored) {
        }
        try {
            java.lang.reflect.Field field = response.getClass().getField("errorMessage");
            Object value = field.get(response);
            if (value != null && !value.toString().isBlank()) return value.toString();
        } catch (Throwable ignored) {
        }
        return "The economy provider returned an unsuccessful response.";
    }

    private boolean depositUsingCommand(Player player, double amount) {
        String template = getConfig().getString("settings.payment-command", "givemoney %player% %amount%");
        if (template == null || template.isBlank()) {
            getLogger().warning("No payment command fallback is configured.");
            return false;
        }
        String command = template
                .replace("%player%", player.getName())
                .replace("%amount%", String.format(Locale.US, "%.2f", amount));
        try {
            Object server = getServer();
            Method getConsole = server.getClass().getMethod("getConsoleSender");
            Object console = getConsole.invoke(server);
            Method dispatch = null;
            for (Method method : server.getClass().getMethods()) {
                if (method.getName().equals("dispatchCommand") && method.getParameterCount() == 2
                        && method.getParameterTypes()[1] == String.class) {
                    dispatch = method;
                    break;
                }
            }
            if (dispatch == null) {
                getLogger().warning("Could not find Bukkit dispatchCommand for payment fallback.");
                return false;
            }
            Object result = dispatch.invoke(server, console, command);
            boolean success = !(result instanceof Boolean) || (Boolean) result;
            if (success) {
                getLogger().info("Paid " + player.getName() + " " + formatMoney(amount)
                        + " using command fallback: /" + command);
            } else {
                getLogger().warning("Payment command returned false: /" + command);
            }
            return success;
        } catch (Throwable error) {
            getLogger().warning("Payment command fallback failed: " + error.getClass().getSimpleName()
                    + ": " + error.getMessage());
            return false;
        }
    }

    private ItemStack moveIntoSellSlots(Inventory inventory, ItemStack moving) {
        if (isEmpty(moving)) {
            return null;
        }
        for (int slot = 0; slot < SELL_SLOTS && moving.getAmount() > 0; slot++) {
            ItemStack existing = inventory.getItem(slot);
            if (isEmpty(existing)) {
                int amount = Math.min(moving.getAmount(), moving.getMaxStackSize());
                ItemStack placed = moving.clone();
                placed.setAmount(amount);
                inventory.setItem(slot, placed);
                moving.setAmount(moving.getAmount() - amount);
            } else {
                stripValueLore(existing);
                stripValueLore(moving);
                if (!existing.isSimilar(moving)) {
                    applyValueLore(existing, sellPrices.get(existing.getType()));
                    continue;
                }
                int capacity = existing.getMaxStackSize() - existing.getAmount();
                if (capacity > 0) {
                    int amount = Math.min(capacity, moving.getAmount());
                    existing.setAmount(existing.getAmount() + amount);
                    moving.setAmount(moving.getAmount() - amount);
                }
                applyValueLore(existing, sellPrices.get(existing.getType()));
            }
        }
        return moving.getAmount() <= 0 ? null : moving;
    }

    private void returnItems(Player player, Inventory inventory) {
        PlayerInventory playerInventory = player.getInventory();
        for (int slot = 0; slot < SELL_SLOTS; slot++) {
            ItemStack item = inventory.getItem(slot);
            if (isEmpty(item)) {
                continue;
            }
            inventory.setItem(slot, null);
            stripValueLore(item);
            Map<Integer, ItemStack> leftovers = playerInventory.addItem(item);
            for (ItemStack leftover : leftovers.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), leftover);
            }
        }
        openMenus.remove(player.getUniqueId());
    }


    private void applyValueLore(ItemStack item, double unitPrice) {
        if (isEmpty(item) || unitPrice <= 0.0) {
            return;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return;
        }
        List<String> lore = meta.hasLore() && meta.getLore() != null
                ? new ArrayList<>(meta.getLore())
                : new ArrayList<>();
        removeValueLoreLines(lore);
        String line = stackValueLore
                .replace("%value%", formatMoney(unitPrice * item.getAmount()))
                .replace("%unit%", formatMoney(unitPrice));
        lore.add(color(line));
        meta.setLore(lore);
        item.setItemMeta(meta);
    }

    private void stripValueLore(ItemStack item) {
        if (isEmpty(item)) {
            return;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasLore() || meta.getLore() == null) {
            return;
        }
        List<String> lore = new ArrayList<>(meta.getLore());
        if (removeValueLoreLines(lore)) {
            meta.setLore(lore.isEmpty() ? null : lore);
            item.setItemMeta(meta);
        }
    }

    private boolean removeValueLoreLines(List<String> lore) {
        String marker = ChatColor.stripColor(color(stackValueLore
                .replace("%value%", "")
                .replace("%unit%", "")))
                .replace("$", "")
                .replace("(", "")
                .replace(")", "")
                .trim();
        return lore.removeIf(line -> {
            String plain = ChatColor.stripColor(line);
            return plain != null && plain.startsWith("Worth:") && plain.contains("each");
        });
    }

    private boolean isSellable(ItemStack item) {
        return !isEmpty(item) && sellPrices.containsKey(item.getType());
    }

    private boolean isEmpty(ItemStack item) {
        return item == null || item.getType() == Material.AIR || item.getAmount() <= 0;
    }

    private List<String> colorList(List<String> lines) {
        List<String> result = new ArrayList<>();
        for (String line : lines) {
            result.add(color(line));
        }
        return result;
    }

    private String message(String key, String fallback) {
        return getConfig().getString("messages." + key, fallback);
    }

    private String formatMoney(double amount) {
        return moneyFormat.format(amount);
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }

    private static final class SellHolder implements InventoryHolder {
        private final UUID playerId;
        private final Player player;
        private Inventory inventory;
        private boolean updateQueued;

        private SellHolder(Player player) {
            this.player = player;
            this.playerId = player.getUniqueId();
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }
}
