package dev.techprogression;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.inventory.PrepareSmithingEvent;
import org.bukkit.event.inventory.SmithItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class TechProgressionPlugin extends JavaPlugin implements Listener {

    private final Map<String, Technology> technologies = new LinkedHashMap<>();
    private final Map<Material, Technology> itemRequirements = new EnumMap<>(Material.class);
    private final Map<InventoryType, StationRequirement> stationRequirements = new EnumMap<>(InventoryType.class);
    private final Map<UUID, Set<String>> unlocked = new HashMap<>();
    private final Map<UUID, PermissionAttachment> permissionAttachments = new HashMap<>();
    private final Map<UUID, Map<Integer, String>> menuActions = new HashMap<>();

    private Economy economy;
    private File dataFile;
    private YamlConfiguration dataConfig;
    private boolean opBypass;
    private boolean exposePermissions;
    private String bypassPermission;
    private String currencySymbol;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadData();
        loadEverything();
        setupEconomy();
        getServer().getPluginManager().registerEvents(this, this);

        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            new TechExpansion(this).register();
            getLogger().info("PlaceholderAPI expansion registered.");
        }

        getLogger().info("Loaded " + technologies.size() + " technologies, "
                + itemRequirements.size() + " item restrictions and "
                + stationRequirements.size() + " station restrictions.");
    }

    @Override
    public void onDisable() {
        for (Player player : getServer().getOnlinePlayers()) {
            PermissionAttachment attachment = permissionAttachments.remove(player.getUniqueId());
            if (attachment != null) player.removeAttachment(attachment);
        }
        saveData();
    }

    private void loadEverything() {
        reloadConfig();
        technologies.clear();
        itemRequirements.clear();
        stationRequirements.clear();

        opBypass = getConfig().getBoolean("settings.op-bypass", false);
        exposePermissions = getConfig().contains("settings.expose-bukkit-permissions")
                ? getConfig().getBoolean("settings.expose-bukkit-permissions", true)
                : getConfig().getBoolean("settings.sync-luckperms-permissions", true);
        bypassPermission = getConfig().getString("settings.bypass-permission", "techprogression.bypass");
        currencySymbol = getConfig().getString("settings.currency-symbol", "$");

        ConfigurationSection section = getConfig().getConfigurationSection("technologies");
        if (section != null) {
            for (String id : section.getKeys(false)) {
                String path = "technologies." + id;
                Map<Material, Integer> itemCosts = new LinkedHashMap<>();
                ConfigurationSection itemCostSection = getConfig().getConfigurationSection(path + ".item-costs");
                if (itemCostSection != null) {
                    for (String materialName : itemCostSection.getKeys(false)) {
                        Material material = matchMaterialCompat(materialName);
                        int amount = itemCostSection.getInt(materialName, 0);
                        if (material == null) {
                            getLogger().warning("Unknown item-cost material in " + id + ": " + materialName);
                            continue;
                        }
                        if (amount <= 0) {
                            getLogger().warning("Invalid item-cost amount in " + id + " for " + materialName + ": " + amount);
                            continue;
                        }
                        itemCosts.put(material, amount);
                    }
                }

                List<String> requires = new ArrayList<>();
                Object rawRequires = getConfig().get(path + ".requires");
                if (rawRequires instanceof List<?> list) {
                    for (Object value : list) {
                        String requirement = emptyToNull(String.valueOf(value));
                        if (requirement != null) requires.add(requirement);
                    }
                } else if (rawRequires != null) {
                    String requirement = emptyToNull(String.valueOf(rawRequires));
                    if (requirement != null) requires.add(requirement);
                }

                Material icon = matchMaterialCompat(getConfig().getString(path + ".icon"));

                Technology tech = new Technology(
                        id,
                        getConfig().getString(path + ".name", pretty(id)),
                        getConfig().getString(path + ".category", "Other"),
                        getConfig().getDouble(path + ".cost", 0.0),
                        Collections.unmodifiableList(requires),
                        getConfig().getString(path + ".permission", "tech." + id),
                        Collections.unmodifiableMap(itemCosts),
                        icon
                );
                technologies.put(id.toLowerCase(Locale.ROOT), tech);

                for (String materialName : getConfig().getStringList(path + ".items")) {
                    Material material = matchMaterialCompat(materialName);
                    if (material == null) {
                        getLogger().warning("Unknown material in " + id + ": " + materialName);
                        continue;
                    }
                    itemRequirements.put(material, tech);
                }
            }
        }

        ConfigurationSection stations = getConfig().getConfigurationSection("stations");
        if (stations != null) {
            for (String id : stations.getKeys(false)) {
                String path = "stations." + id;
                if (!getConfig().getBoolean(path + ".enabled", true)) continue;
                String typeName = getConfig().getString(path + ".inventory-type");
                String permission = getConfig().getString(path + ".permission");
                String name = getConfig().getString(path + ".name", pretty(id));
                if (typeName == null || permission == null) continue;
                try {
                    InventoryType type = InventoryType.valueOf(typeName.toUpperCase(Locale.ROOT));
                    stationRequirements.put(type, new StationRequirement(permission, name));
                } catch (IllegalArgumentException ex) {
                    getLogger().warning("Unknown inventory type for " + id + ": " + typeName);
                }
            }
        }
    }

    private Material matchMaterialCompat(String materialName) {
        if (materialName == null) return null;
        String normalized = materialName.trim().toUpperCase(Locale.ROOT);

        // Minecraft calls this item eye_of_ender, while Bukkit uses ENDER_EYE.
        // Accept both names so item-cost and locked-item technologies are loaded
        // through the same generic maps as every other technology.
        if (normalized.equals("EYE_OF_ENDER") || normalized.equals("MINECRAFT:EYE_OF_ENDER")) {
            normalized = "ENDER_EYE";
        }

        Material material = Material.matchMaterial(normalized);
        if (material == null && normalized.startsWith("MINECRAFT:")) {
            material = Material.matchMaterial(normalized.substring("MINECRAFT:".length()));
        }
        return material;
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            economy = null;
            getLogger().warning("Vault was not found. Purchases will be disabled.");
            return false;
        }
        try {
            Object servicesManager = getServer().getServicesManager();
            Object registration = servicesManager.getClass()
                    .getMethod("getRegistration", Class.class)
                    .invoke(servicesManager, Economy.class);
            economy = registration == null
                    ? null
                    : (Economy) registration.getClass().getMethod("getProvider").invoke(registration);
        } catch (ReflectiveOperationException | ClassCastException ex) {
            economy = null;
            getLogger().warning("Could not access the Vault economy service: " + ex.getMessage());
        }
        if (economy == null) {
            getLogger().warning("No Vault economy provider was found. Purchases will be disabled.");
            return false;
        }
        getLogger().info("Using Vault economy provider: " + economy.getName());
        return true;
    }

    private void loadData() {
        dataFile = new File(getDataFolder(), "players.yml");
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
        unlocked.clear();
        ConfigurationSection players = dataConfig.getConfigurationSection("players");
        if (players == null) return;
        for (String uuidText : players.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(uuidText);
                unlocked.put(uuid, new HashSet<>(dataConfig.getStringList("players." + uuidText + ".unlocked")));
            } catch (IllegalArgumentException ignored) {
                getLogger().warning("Invalid UUID in players.yml: " + uuidText);
            }
        }
    }

    private void saveData() {
        if (dataConfig == null || dataFile == null) return;
        dataConfig.set("players", null);
        for (Map.Entry<UUID, Set<String>> entry : unlocked.entrySet()) {
            List<String> values = new ArrayList<>(entry.getValue());
            Collections.sort(values);
            dataConfig.set("players." + entry.getKey() + ".unlocked", values);
        }
        try {
            dataConfig.save(dataFile);
        } catch (IOException ex) {
            getLogger().severe("Could not save players.yml: " + ex.getMessage());
        }
    }

    public boolean isUnlocked(UUID uuid, String techId) {
        return unlocked.getOrDefault(uuid, Collections.emptySet()).contains(techId.toLowerCase(Locale.ROOT));
    }

    private void unlock(Player player, Technology tech) {
        unlocked.computeIfAbsent(player.getUniqueId(), ignored -> new HashSet<>()).add(tech.id());
        saveData();
        syncPermission(player, tech.permission(), true);
    }

    private void reset(Player player, Technology tech) {
        unlocked.computeIfAbsent(player.getUniqueId(), ignored -> new HashSet<>()).remove(tech.id());
        saveData();
        syncPermission(player, tech.permission(), false);
    }

    private PermissionAttachment attachment(Player player) {
        return permissionAttachments.computeIfAbsent(
                player.getUniqueId(),
                ignored -> player.addAttachment(this)
        );
    }

    private void syncPermission(Player player, String permission, boolean value) {
        if (!exposePermissions || permission == null || permission.isBlank()) return;
        attachment(player).setPermission(permission, value);
        player.recalculatePermissions();
    }

    private void syncAllPermissions(Player player) {
        PermissionAttachment old = permissionAttachments.remove(player.getUniqueId());
        if (old != null) player.removeAttachment(old);
        if (!exposePermissions) {
            player.recalculatePermissions();
            return;
        }
        PermissionAttachment current = attachment(player);
        for (Technology tech : technologies.values()) {
            current.setPermission(
                    tech.permission(),
                    isUnlocked(player.getUniqueId(), tech.id())
            );
        }
        player.recalculatePermissions();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        syncAllPermissions(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        menuActions.remove(event.getPlayer().getUniqueId());
        PermissionAttachment attachment = permissionAttachments.remove(event.getPlayer().getUniqueId());
        if (attachment != null) event.getPlayer().removeAttachment(attachment);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        return switch (name) {
            case "techshop" -> handleShop(sender);
            case "techbuy" -> handleBuy(sender, args);
            case "techunlock" -> handleAdminUnlock(sender, args);
            case "techreset" -> handleAdminReset(sender, args);
            case "techunlockall" -> handleUnlockAll(sender, args, false);
            case "techunlockprogression" -> handleUnlockAll(sender, args, true);
            case "techresetall" -> handleResetAll(sender, args);
            case "techlist" -> handleList(sender);
            case "techreload" -> handleReload(sender);
            case "techstatus", "checktech" -> handleStatus(sender, args);
            case "tech" -> handleMain(sender, args);
            default -> false;
        };
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        if (name.equals("tech") && args.length == 1) {
            return complete(args[0], List.of("buy", "status", "list", "unlock", "reset", "unlockall", "unlockprogression", "resetall", "reload"));
        }
        if (name.equals("tech") && args.length == 2 && Set.of("buy", "status", "unlock", "reset").contains(args[0].toLowerCase(Locale.ROOT))) {
            return complete(args[1], technologies.keySet());
        }
        if (Set.of("techbuy", "techunlock", "techreset", "techstatus", "checktech").contains(name) && args.length == 1) {
            return complete(args[0], technologies.keySet());
        }
        if (Set.of("techunlock", "techreset").contains(name) && args.length == 2) {
            List<String> names = new ArrayList<>();
            for (Player player : getServer().getOnlinePlayers()) names.add(player.getName());
            return complete(args[1], names);
        }
        if (Set.of("techunlockall", "techunlockprogression", "techresetall").contains(name) && args.length == 1) {
            List<String> names = new ArrayList<>();
            for (Player player : getServer().getOnlinePlayers()) names.add(player.getName());
            return complete(args[0], names);
        }
        if (name.equals("tech") && args.length == 2 && Set.of("unlockall", "unlockprogression", "resetall").contains(args[0].toLowerCase(Locale.ROOT))) {
            List<String> names = new ArrayList<>();
            for (Player player : getServer().getOnlinePlayers()) names.add(player.getName());
            return complete(args[1], names);
        }
        return Collections.emptyList();
    }

    private static List<String> complete(String input, Collection<String> options) {
        String lower = input == null ? "" : input.toLowerCase(Locale.ROOT);
        List<String> result = new ArrayList<>();
        for (String option : options) if (option.toLowerCase(Locale.ROOT).startsWith(lower)) result.add(option);
        Collections.sort(result);
        return result;
    }

    private boolean handleMain(CommandSender sender, String[] args) {
        if (args.length == 0) {
            return handleShop(sender);
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        String[] remaining = Arrays.copyOfRange(args, 1, args.length);
        return switch (sub) {
            case "buy" -> handleBuy(sender, remaining);
            case "status", "check" -> handleStatus(sender, remaining);
            case "list" -> handleList(sender);
            case "unlock" -> handleAdminUnlock(sender, remaining);
            case "reset" -> handleAdminReset(sender, remaining);
            case "unlockall" -> handleUnlockAll(sender, remaining, false);
            case "unlockprogression" -> handleUnlockAll(sender, remaining, true);
            case "resetall" -> handleResetAll(sender, remaining);
            case "reload" -> handleReload(sender);
            default -> {
                sender.sendMessage(msg("unknown-tech", Map.of("tech", sub)));
                yield true;
            }
        };
    }

    private boolean handleBuy(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(msg("player-only", Map.of()));
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(color("&eUsage: /techbuy <technology>"));
            return true;
        }
        Technology tech = technology(args[0]);
        if (tech == null) {
            player.sendMessage(msg("unknown-tech", Map.of("tech", args[0])));
            return true;
        }
        if (isUnlocked(player.getUniqueId(), tech.id())) {
            player.sendMessage(msg("already-unlocked", Map.of("technology", tech.name())));
            return true;
        }
        attemptPurchase(player, tech);
        return true;
    }

    private boolean handleAdminUnlock(CommandSender sender, String[] args) {
        if (!sender.hasPermission("techprogression.admin")) {
            sender.sendMessage(msg("no-permission", Map.of()));
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(color("&eUsage: /techunlock <technology> [player]"));
            return true;
        }
        Technology tech = technology(args[0]);
        if (tech == null) {
            sender.sendMessage(msg("unknown-tech", Map.of("tech", args[0])));
            return true;
        }
        Player target = resolveTarget(sender, args.length >= 2 ? args[1] : null);
        if (target == null) return true;
        unlock(target, tech);
        sender.sendMessage(msg("admin-unlocked", placeholders(tech, target)));
        return true;
    }

    private boolean handleAdminReset(CommandSender sender, String[] args) {
        if (!sender.hasPermission("techprogression.admin")) {
            sender.sendMessage(msg("no-permission", Map.of()));
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(color("&eUsage: /techreset <technology> [player]"));
            return true;
        }
        Technology tech = technology(args[0]);
        if (tech == null) {
            sender.sendMessage(msg("unknown-tech", Map.of("tech", args[0])));
            return true;
        }
        Player target = resolveTarget(sender, args.length >= 2 ? args[1] : null);
        if (target == null) return true;
        reset(target, tech);
        sender.sendMessage(msg("reset", placeholders(tech, target)));
        return true;
    }


    private boolean handleUnlockAll(CommandSender sender, String[] args, boolean excludeEndResearch) {
        if (!sender.hasPermission("techprogression.admin")) {
            sender.sendMessage(msg("no-permission", Map.of()));
            return true;
        }
        Player target = resolveTarget(sender, args.length >= 1 ? args[0] : null);
        if (target == null) return true;

        int count = 0;
        for (Technology tech : technologies.values()) {
            if (excludeEndResearch && tech.id().equalsIgnoreCase("end_research")) continue;
            if (!isUnlocked(target.getUniqueId(), tech.id())) {
                unlocked.computeIfAbsent(target.getUniqueId(), ignored -> new HashSet<>()).add(tech.id());
                count++;
            }
        }
        saveData();
        syncAllPermissions(target);
        sender.sendMessage(color("&aUnlocked &e" + count + " &atechnologies for &f" + target.getName() + "&a."));
        if (excludeEndResearch) {
            sender.sendMessage(color("&7End Research was left locked for testing."));
        }
        return true;
    }

    private boolean handleResetAll(CommandSender sender, String[] args) {
        if (!sender.hasPermission("techprogression.admin")) {
            sender.sendMessage(msg("no-permission", Map.of()));
            return true;
        }
        Player target = resolveTarget(sender, args.length >= 1 ? args[0] : null);
        if (target == null) return true;

        int count = unlocked.getOrDefault(target.getUniqueId(), Collections.emptySet()).size();
        unlocked.put(target.getUniqueId(), new HashSet<>());
        saveData();
        syncAllPermissions(target);
        sender.sendMessage(color("&cReset &e" + count + " &ctechnologies for &f" + target.getName() + "&c."));
        return true;
    }

    private boolean handleStatus(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(msg("player-only", Map.of()));
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(color("&eUsage: /techstatus <technology>"));
            return true;
        }
        Technology tech = technology(args[0]);
        if (tech == null) {
            player.sendMessage(msg("unknown-tech", Map.of("tech", args[0])));
            return true;
        }
        boolean state = isUnlocked(player.getUniqueId(), tech.id());
        player.sendMessage(color("&e" + tech.name() + " &7- " + (state ? "&aUNLOCKED" : "&cLOCKED")));
        if (!state) {
            if (!tech.itemCosts().isEmpty()) {
                player.sendMessage(color("&6Required items: &e" + formatItemCosts(tech.itemCosts())));
            } else {
                player.sendMessage(color("&6Cost: &e" + currencySymbol + formatMoney(tech.cost())));
            }
            if (!tech.requires().isEmpty()) {
                player.sendMessage(color("&6Requires: &e" + formatRequirements(tech.requires())));
            }
        }
        return true;
    }

    private boolean handleList(CommandSender sender) {
        sender.sendMessage(color("&6Technologies:"));
        for (Technology tech : technologies.values()) {
            boolean state = sender instanceof Player player && isUnlocked(player.getUniqueId(), tech.id());
            sender.sendMessage(color((state ? "&a✔ " : "&c✘ ") + "&e" + tech.id() + " &7- " + tech.name()));
        }
        return true;
    }

    private boolean handleReload(CommandSender sender) {
        if (!sender.hasPermission("techprogression.reload")) {
            sender.sendMessage(msg("no-permission", Map.of()));
            return true;
        }
        loadEverything();
        setupEconomy();
        for (Player player : getServer().getOnlinePlayers()) {
            syncAllPermissions(player);
        }
        sender.sendMessage(msg("reloaded", Map.of()));
        return true;
    }

    private boolean handleShop(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(msg("player-only", Map.of()));
            return true;
        }
        openMainMenu(player);
        return true;
    }

    private void openMainMenu(Player player) {
        String title = color(getConfig().getString("gui.main-title", "&8Technology Shop"));
        Inventory inventory = Bukkit.createInventory(null, 27, title);
        Map<Integer, String> actions = new HashMap<>();

        LinkedHashSet<String> categories = new LinkedHashSet<>();
        for (Technology tech : technologies.values()) categories.add(tech.category());

        int[] slots = {10, 11, 12, 14, 15, 16, 21, 23};
        int index = 0;
        for (String category : categories) {
            if (index >= slots.length) break;
            int slot = slots[index++];
            Material icon = categoryIcon(category);
            String display = categoryDisplayName(category);
            ItemStack item = menuItem(icon, "&6" + display, List.of("&7View " + display + " technologies", "", "&eClick to open"));
            inventory.setItem(slot, item);
            actions.put(slot, "category:" + category);
        }

        inventory.setItem(26, menuItem(Material.BARRIER, "&cClose", List.of()));
        actions.put(26, "close");
        menuActions.put(player.getUniqueId(), actions);
        player.openInventory(inventory);
    }

    private void openCategoryMenu(Player player, String category) {
        List<Technology> categoryTechs = new ArrayList<>();
        for (Technology tech : technologies.values()) {
            if (tech.category().equalsIgnoreCase(category)) categoryTechs.add(tech);
        }

        int rows = Math.max(3, Math.min(6, (categoryTechs.size() + 8) / 9 + 1));
        int size = rows * 9;
        String title = color("&8" + categoryDisplayName(category) + " Technology");
        Inventory inventory = Bukkit.createInventory(null, size, title);
        Map<Integer, String> actions = new HashMap<>();

        int slot = 0;
        for (Technology tech : categoryTechs) {
            if (slot >= size - 9) break;
            inventory.setItem(slot, technologyItem(player, tech));
            actions.put(slot, "tech:" + tech.id());
            slot++;
        }

        int backSlot = size - 5;
        int closeSlot = size - 1;
        inventory.setItem(backSlot, menuItem(Material.ARROW, "&cBack", List.of("&7Return to the technology shop")));
        inventory.setItem(closeSlot, menuItem(Material.BARRIER, "&cClose", List.of()));
        actions.put(backSlot, "back");
        actions.put(closeSlot, "close");

        menuActions.put(player.getUniqueId(), actions);
        player.openInventory(inventory);
    }

    private ItemStack technologyItem(Player player, Technology tech) {
        Material icon = tech.icon();
        if (icon == null) {
            for (Map.Entry<Material, Technology> entry : itemRequirements.entrySet()) {
                if (entry.getValue().id().equals(tech.id())) {
                    icon = entry.getKey();
                    break;
                }
            }
        }
        if (icon == null) icon = Material.BOOK;

        boolean state = isUnlocked(player.getUniqueId(), tech.id());
        List<String> lore = new ArrayList<>();
        lore.add("&8Technology: " + tech.category());
        lore.add("");
        if (state) {
            lore.add("&aStatus: Unlocked");
            lore.add("");
            lore.add("&7Already purchased");
            return menuItem(icon, "&a" + tech.name() + " ✔", lore);
        }

        if (!tech.itemCosts().isEmpty()) {
            lore.add("&6Required Materials:");
            for (Map.Entry<Material, Integer> entry : tech.itemCosts().entrySet()) {
                lore.add("&f" + entry.getValue() + "x " + pretty(entry.getKey().name().toLowerCase(Locale.ROOT)));
            }
        } else {
            lore.add("&6Cost: &e" + currencySymbol + formatMoney(tech.cost()));
        }

        if (!tech.requires().isEmpty()) {
            lore.add("");
            lore.add("&6Required Technologies:");
            for (String requirementId : tech.requires()) {
                Technology requirement = technology(requirementId);
                boolean has = isUnlocked(player.getUniqueId(), requirementId);
                lore.add((has ? "&a✔ " : "&c✘ ") + "&7" + (requirement == null ? pretty(requirementId) : requirement.name()));
            }
        }

        lore.add("");
        lore.add("&cStatus: Locked");
        lore.add("");
        lore.add("&eClick to purchase");
        return menuItem(icon, "&6" + tech.name(), lore);
    }

    private ItemStack menuItem(Material material, String name, List<String> loreLines) {
        ItemStack stack = new ItemStack(material == null ? Material.BOOK : material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(name));
            List<String> lore = new ArrayList<>();
            for (String line : loreLines) lore.add(color(line));
            meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private Material categoryIcon(String category) {
        String configured = getConfig().getString("gui.category-icons." + category.toLowerCase(Locale.ROOT).replace(' ', '_'));
        Material material = matchMaterialCompat(configured);
        if (material != null) return material;
        return switch (category.toLowerCase(Locale.ROOT)) {
            case "tools" -> Material.DIAMOND_PICKAXE;
            case "armor" -> Material.DIAMOND_CHESTPLATE;
            case "utility" -> Material.SHIELD;
            case "magic" -> Material.ENCHANTING_TABLE;
            case "alchemy", "brewing" -> Material.BREWING_STAND;
            case "redstone" -> Material.REDSTONE;
            case "storage" -> Material.ENDER_CHEST;
            case "end game", "endgame" -> Material.END_PORTAL_FRAME;
            default -> Material.BOOK;
        };
    }

    private String categoryDisplayName(String category) {
        if (category.equalsIgnoreCase("Alchemy")) return "Brewing";
        return category;
    }

    private List<String> missingRequirements(Player player, Technology tech) {
        List<String> missing = new ArrayList<>();
        for (String requirement : tech.requires()) {
            if (!isUnlocked(player.getUniqueId(), requirement)) missing.add(requirement);
        }
        return missing;
    }

    private String formatRequirements(Collection<String> requirementIds) {
        List<String> names = new ArrayList<>();
        for (String id : requirementIds) {
            Technology required = technology(id);
            names.add(required == null ? pretty(id) : required.name());
        }
        return String.join(", ", names);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onTechnologyMenuClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        Map<Integer, String> actions = menuActions.get(player.getUniqueId());
        if (actions == null) return;
        if (event.getRawSlot() < 0 || event.getRawSlot() >= event.getView().getTopInventory().getSize()) return;

        event.setCancelled(true);
        String action = actions.get(event.getRawSlot());
        if (action == null) return;

        if (action.equals("close")) {
            player.closeInventory();
            return;
        }
        if (action.equals("back")) {
            openMainMenu(player);
            return;
        }
        if (action.startsWith("category:")) {
            openCategoryMenu(player, action.substring("category:".length()));
            return;
        }
        if (action.startsWith("tech:")) {
            Technology tech = technology(action.substring("tech:".length()));
            if (tech == null) return;
            if (isUnlocked(player.getUniqueId(), tech.id())) {
                player.sendMessage(msg("already-unlocked", Map.of("technology", tech.name())));
            } else {
                attemptPurchase(player, tech);
            }
            openCategoryMenu(player, tech.category());
        }
    }

    private void attemptPurchase(Player player, Technology tech) {
        List<String> missingRequirements = missingRequirements(player, tech);
        if (!missingRequirements.isEmpty()) {
            player.sendMessage(msg("missing-prerequisite", Map.of("requirement", formatRequirements(missingRequirements))));
            return;
        }
        if (!tech.itemCosts().isEmpty()) {
            Map<Material, Integer> missing = missingItems(player, tech.itemCosts());
            if (!missing.isEmpty()) {
                Map<String, String> values = placeholders(tech, player);
                values.put("items", formatItemCosts(missing));
                player.sendMessage(msg("insufficient-items", values));
                return;
            }
            removeItems(player, tech.itemCosts());
            unlock(player, tech);
            Map<String, String> values = placeholders(tech, player);
            values.put("items", formatItemCosts(tech.itemCosts()));
            player.sendMessage(msg("purchased-items", values));
            return;
        }
        if (economy == null) {
            player.sendMessage(msg("no-economy", Map.of()));
            return;
        }
        if (!economy.has(player, tech.cost())) {
            player.sendMessage(msg("insufficient-money", placeholders(tech, player)));
            return;
        }
        EconomyResponse response = economy.withdrawPlayer(player, tech.cost());
        if (!response.transactionSuccess()) {
            player.sendMessage(msg("insufficient-money", placeholders(tech, player)));
            getLogger().warning("Economy withdrawal failed for " + player.getName() + ": " + response.errorMessage);
            return;
        }
        unlock(player, tech);
        player.sendMessage(msg("purchased", placeholders(tech, player)));
    }

    private Player resolveTarget(CommandSender sender, String name) {
        if (name != null) {
            Player target = Bukkit.getPlayerExact(name);
            if (target == null) sender.sendMessage(color("&cPlayer not found: &e" + name));
            return target;
        }
        if (sender instanceof Player player) return player;
        sender.sendMessage(msg("player-only", Map.of()));
        return null;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInventoryOpen(InventoryOpenEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        StationRequirement requirement = stationRequirements.get(event.getInventory().getType());
        if (requirement == null || allowed(player, requirement.permission())) return;
        event.setCancelled(true);
        player.sendMessage(msg("locked-station", Map.of("technology", requirement.name())));
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        ItemStack result = event.getInventory().getResult();
        if (result == null || result.getType().isAir()) return;
        Player player = firstPlayer(event.getViewers());
        Technology tech = itemRequirements.get(result.getType());
        if (player != null && tech != null && !allowed(player, tech)) event.getInventory().setResult(null);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCraft(CraftItemEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        // Arclight does not reliably expose every crafting output through
        // CraftItemEvent#getCurrentItem (notably some shapeless recipes).
        // Read the recipe's declared result first, then fall back to the
        // clicked result item for normal Bukkit/Paper behaviour.
        ItemStack result = craftRecipeResult(event);
        if (result == null || result.getType().isAir()) {
            result = event.getCurrentItem();
        }
        if (result == null || result.getType().isAir()) return;

        Technology tech = itemRequirements.get(result.getType());
        if (tech == null || allowed(player, tech)) return;

        event.setCancelled(true);
        event.setCurrentItem(null);
        player.updateInventory();
        player.sendMessage(msg("locked-item", Map.of("technology", tech.name())));
    }

    private ItemStack craftRecipeResult(CraftItemEvent event) {
        try {
            Object recipe = event.getClass().getMethod("getRecipe").invoke(event);
            if (recipe == null) return null;
            Object result = recipe.getClass().getMethod("getResult").invoke(recipe);
            return result instanceof ItemStack stack ? stack : null;
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPrepareSmithing(PrepareSmithingEvent event) {
        ItemStack result = event.getResult();
        if (result == null || result.getType().isAir()) return;
        Player player = firstPlayer(event.getViewers());
        Technology tech = itemRequirements.get(result.getType());
        if (player != null && tech != null && !allowed(player, tech)) event.setResult(null);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSmith(SmithItemEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        ItemStack result = event.getCurrentItem();
        if (result == null || result.getType().isAir()) return;
        Technology tech = itemRequirements.get(result.getType());
        if (tech == null || allowed(player, tech)) return;
        event.setCancelled(true);
        event.setCurrentItem(null);
        player.sendMessage(msg("locked-item", Map.of("technology", tech.name())));
    }

    private Map<Material, Integer> missingItems(Player player, Map<Material, Integer> costs) {
        Map<Material, Integer> missing = new LinkedHashMap<>();
        for (Map.Entry<Material, Integer> entry : costs.entrySet()) {
            int found = 0;
            for (ItemStack stack : player.getInventory().getContents()) {
                if (stack != null && stack.getType() == entry.getKey()) found += stack.getAmount();
            }
            if (found < entry.getValue()) missing.put(entry.getKey(), entry.getValue() - found);
        }
        return missing;
    }

    private void removeItems(Player player, Map<Material, Integer> costs) {
        for (Map.Entry<Material, Integer> entry : costs.entrySet()) {
            int remaining = entry.getValue();
            ItemStack[] contents = player.getInventory().getContents();
            for (int slot = 0; slot < contents.length && remaining > 0; slot++) {
                ItemStack stack = contents[slot];
                if (stack == null || stack.getType() != entry.getKey()) continue;
                int take = Math.min(stack.getAmount(), remaining);
                remaining -= take;
                if (take == stack.getAmount()) player.getInventory().setItem(slot, null);
                else stack.setAmount(stack.getAmount() - take);
            }
        }
        player.updateInventory();
    }

    private static String formatItemCosts(Map<Material, Integer> costs) {
        List<String> parts = new ArrayList<>();
        for (Map.Entry<Material, Integer> entry : costs.entrySet()) {
            parts.add(entry.getValue() + "x " + pretty(entry.getKey().name().toLowerCase(Locale.ROOT)));
        }
        return String.join(", ", parts);
    }

    private boolean allowed(Player player, Technology tech) {
        return allowed(player, tech.permission()) || isUnlocked(player.getUniqueId(), tech.id());
    }

    private boolean allowed(Player player, String permission) {
        if (player.hasPermission(bypassPermission)) return true;
        if (opBypass && player.isOp()) return true;
        return player.hasPermission(permission);
    }

    private Player firstPlayer(Iterable<HumanEntity> viewers) {
        for (HumanEntity viewer : viewers) if (viewer instanceof Player player) return player;
        return null;
    }

    private Technology technology(String id) {
        return id == null ? null : technologies.get(id.toLowerCase(Locale.ROOT));
    }

    private Map<String, String> placeholders(Technology tech, Player player) {
        Map<String, String> values = new HashMap<>();
        values.put("technology", tech.name());
        values.put("tech", tech.id());
        values.put("cost", formatMoney(tech.cost()));
        values.put("currency", currencySymbol);
        values.put("player", player.getName());
        values.put("items", formatItemCosts(tech.itemCosts()));
        return values;
    }

    private String msg(String key, Map<String, String> replacements) {
        String prefix = getConfig().getString("messages.prefix", "");
        String text = getConfig().getString("messages." + key, key);
        for (Map.Entry<String, String> entry : replacements.entrySet()) {
            text = text.replace("%" + entry.getKey() + "%", entry.getValue());
        }
        return color(prefix + text);
    }

    private static String formatMoney(double amount) {
        if (Math.rint(amount) == amount) return Long.toString((long) amount);
        return String.format(Locale.US, "%.2f", amount);
    }

    private static String color(String value) {
        return ChatColor.translateAlternateColorCodes('&', value == null ? "" : value);
    }

    private static String pretty(String id) {
        StringBuilder builder = new StringBuilder();
        for (String part : id.split("_")) {
            if (!builder.isEmpty()) builder.append(' ');
            if (!part.isEmpty()) builder.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return builder.toString();
    }

    private static String emptyToNull(String value) {
        return value == null || value.isBlank() ? null : value.toLowerCase(Locale.ROOT);
    }

    public Collection<Technology> technologies() { return technologies.values(); }
    public Technology technologyForPlaceholder(String id) { return technology(id); }

    public record Technology(String id, String name, String category, double cost, List<String> requires, String permission, Map<Material, Integer> itemCosts, Material icon) {}
    private record StationRequirement(String permission, String name) {}

    private static final class TechExpansion extends PlaceholderExpansion {
        private final TechProgressionPlugin plugin;
        private TechExpansion(TechProgressionPlugin plugin) { this.plugin = plugin; }
        @Override public String getIdentifier() { return "techprogression"; }
        @Override public String getAuthor() { return "TechProgression"; }
        @Override public String getVersion() { return plugin.getDescription().getVersion(); }
        @Override public boolean persist() { return true; }
        @Override public String onRequest(OfflinePlayer player, String params) {
            if (player == null || params == null) return "";
            if (params.startsWith("status_")) {
                String id = params.substring("status_".length());
                Technology tech = plugin.technologyForPlaceholder(id);
                if (tech == null) return "Unknown";
                return plugin.isUnlocked(player.getUniqueId(), tech.id()) ? "Unlocked" : "Locked";
            }
            if (params.startsWith("unlocked_")) {
                String id = params.substring("unlocked_".length());
                Technology tech = plugin.technologyForPlaceholder(id);
                return tech != null && plugin.isUnlocked(player.getUniqueId(), tech.id()) ? "true" : "false";
            }
            if (params.startsWith("cost_")) {
                Technology tech = plugin.technologyForPlaceholder(params.substring("cost_".length()));
                return tech == null ? "0" : formatMoney(tech.cost());
            }
            return null;
        }
    }
}
